import 'package:flutter/material.dart';
import 'package:weatherapp_starter_project/controller/global_controller.dart';
import 'package:get/get.dart';
import 'package:geocoding/geocoding.dart';
class HomePage extends StatelessWidget {
   HomePage({Key? key}) : super(key: key);

   final GlobelControlller globelControlller=Get.put(GlobelControlller(),permanent: true);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
