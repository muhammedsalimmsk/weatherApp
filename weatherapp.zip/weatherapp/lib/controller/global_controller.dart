import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:geocoding/geocoding.dart';

class GlobelControlller extends GetxController{
  final RxBool _isLoading =true.obs;
  final RxDouble latitude =0.0.obs;
  final RxDouble longitude =0.0.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    if(_isLoading.isTrue){
      getLocation();
    }
    super.onInit();
  }

  getLocation()async {
    bool isServiceEnabled;
    LocationPermission  locationPermission;
    isServiceEnabled =await Geolocator.isLocationServiceEnabled();
    if(!isServiceEnabled){
      return Future.error("Location is not enabled");
    }

    locationPermission =await Geolocator.checkPermission();
    if(locationPermission==LocationPermission.deniedForever){
      return Future.error("Location permission is denied forever");
    }else if(locationPermission==LocationPermission.denied){
      locationPermission =await Geolocator.requestPermission();
      if(locationPermission==LocationPermission.denied){
        return Future.error("Location permission is denied");
      }
    }
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high).then((value) {
      latitude.value=value.latitude;
      longitude.value=value.longitude;
      _isLoading.value=false;
    });
  }
}